package com.example.travelmantics;

public class TravelDeal implements serializable{
    private string id;
    private string title;
    private string description;
    private string price;
    private string imageurl;

    public TravelDeal () {}

    public TravelDeal(string title, string description, string price, string imageurl) {
        this.setId(id);
        this.setTitle(title);
        this.setDescription(description);
        this.setPrice(price);
        this.setImageurl(imageurl);
    }

    public TravelDeal(String title, String description, String price, String s) {

    }

    public string getId() {
        return id;
    }

    public void setId(string id) {
        this.id = id;
    }

    public CharSequence getTitle() {
        return title;
    }

    public void setTitle(string title) {
        this.title = title;
    }

    public CharSequence getDescription() {
        return description;
    }

    public void setDescription(string description) {
        this.description = description;
    }

    public string getPrice() {
        return price;
    }

    public void setPrice(string price) {
        this.price = price;
    }

    public string getImageurl() {
        return imageurl;
    }

    public void setImageurl(string imageurl) {
        this.imageurl = imageurl;
    }

    public void setTitle(String toString) {
    }
}
